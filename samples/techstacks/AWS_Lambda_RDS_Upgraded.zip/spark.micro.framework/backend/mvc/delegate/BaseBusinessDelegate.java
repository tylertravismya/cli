#header()
package ${aib.getRootPackageName()}.#getDelegatePackageName();

import java.io.IOException;
import java.util.*;


/**
 * Base class for application business delegates.
 * <p>
 * @author ${aib.getAuthor()}
 */
public class BaseBusinessDelegate
{
    protected BaseBusinessDelegate()
    {
    }

//************************************************************************
// Protected / Private Methods
//************************************************************************

}


