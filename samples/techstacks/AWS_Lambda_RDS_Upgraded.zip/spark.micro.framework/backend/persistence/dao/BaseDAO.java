#header()
package ${aib.getRootPackageName()}.#getDAOPackageName();

import java.util.*;

/** 
 * Base class for all application data access objects.
 *
 * @author $aib.getAuthor()
 */
public abstract class BaseDAO extends FrameworkHibernateDAO
{
}
